# Bundesgesetz  
über den Datenschutz

## (Datenschutzgesetz, DSG)

vom 25. September 2020 (Stand am 1. September 2023)

Die Bundesversammlung der Schweizerischen Eidgenossenschaft,

gestützt auf die Artikel 95 Absatz 1, 97 Absatz 1, 122 Absatz 1 und 173 Absatz 2 der Bundesverfassung[1](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e21),  
nach Einsicht in die Botschaft des Bundesrates vom 15. September 2017[2](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e32),

beschliesst:

[1](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e21) [SR **101**](https://www.fedlex.admin.ch/eli/cc/1999/404/de)

[2](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e32) [BBl **2017** 6941](https://www.fedlex.admin.ch/eli/fga/2017/2057/de)

# [1. Kapitel: Zweck und Geltungsbereich sowie Aufsichtsbehörde des Bundes](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_1)

###### [**Art. 1** Zweck](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_1)

Dieses Gesetz bezweckt den Schutz der Persönlichkeit und der Grundrechte von natürlichen Personen, über die Personendaten bearbeitet werden.

###### [**Art. 2** Persönlicher und sachlicher Geltungsbereich](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_2)

1 Dieses Gesetz gilt für die Bearbeitung von Personendaten natürlicher Personen durch:

a.

private Personen;

b.

Bundesorgane.

2 Es ist nicht anwendbar auf:

a.

Personendaten, die von einer natürlichen Person ausschliesslich zum persönlichen Gebrauch bearbeitet werden;

b.

Personendaten, die von den eidgenössischen Räten und den parlamentarischen Kommissionen im Rahmen ihrer Beratungen bearbeitet werden;

c.

Personendaten, die bearbeitet werden durch institutionelle Begünstigte nach Artikel 2 Absatz 1 des Gaststaatgesetzes vom 22. Juni 2007[3](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e85), die in der Schweiz Immunität von der Gerichtsbarkeit geniessen.

3 Das anwendbare Verfahrensrecht regelt die Bearbeitung von Personendaten und die Rechte der betroffenen Personen in Gerichtsverfahren und in Verfahren nach bundesrechtlichen Verfahrensordnungen. Auf erstinstanzliche Verwaltungsverfahren sind die Bestimmungen dieses Gesetzes anwendbar.

4 Die öffentlichen Register des Privatrechtsverkehrs, insbesondere der Zugang zu diesen Registern und die Rechte der betroffenen Personen, werden durch die Spezialbestimmungen des anwendbaren Bundesrechts geregelt. Enthalten die Spezialbestimmungen keine Regelung, so ist dieses Gesetz anwendbar.

[3](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e85) [SR **192.12**](https://www.fedlex.admin.ch/eli/cc/2007/860/de)

###### [**Art. 3** Räumlicher Geltungsbereich](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_3)

1 Dieses Gesetz gilt für Sachverhalte, die sich in der Schweiz auswirken, auch wenn sie im Ausland veranlasst werden.

2 Für privatrechtliche Ansprüche gilt das Bundesgesetz vom 18. Dezember 1987[4](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e112) über das Internationale Privatrecht. Vorbehalten bleiben zudem die Bestimmungen zum räumlichen Geltungsbereich des Strafgesetzbuchs[5](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e123).

[4](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e112) [SR **291**](https://www.fedlex.admin.ch/eli/cc/1988/1776_1776_1776/de)

[5](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e123) [SR **311.0**](https://www.fedlex.admin.ch/eli/cc/54/757_781_799/de)

###### [**Art. 4** Eidgenössischer Datenschutz- und Öffentlichkeitsbeauftragter](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_4)

1 Der Eidgenössische Datenschutz- und Öffentlichkeitsbeauftragte (EDÖB) beaufsichtigt die Anwendung der bundesrechtlichen Datenschutzvorschriften.

2 Von der Aufsicht durch den EDÖB sind ausgenommen:

a.

die Bundesversammlung;

b.

der Bundesrat;

c.

die eidgenössischen Gerichte;

d.

die Bundesanwaltschaft: betreffend die Bearbeitung von Personendaten im Rahmen von Strafverfahren;

e.

Bundesbehörden: betreffend die Bearbeitung von Personendaten im Rahmen einer rechtsprechenden Tätigkeit oder von Verfahren der internationalen Rechtshilfe in Strafsachen.

# [2. Kapitel: Allgemeine Bestimmungen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_2)

## [1. Abschnitt: Begriffe und Grundsätze](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_2/sec_1)

###### [**Art. 5** Begriffe](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_5)

In diesem Gesetz bedeuten:

a.

_Personendaten:_ alle Angaben, die sich auf eine bestimmte oder bestimmbare natürliche Person beziehen;

b.

_betroffene Person__:_ natürliche Person, über die Personendaten bearbeitet werden;

c.

_besonders schützenswerte Personendaten:_

1.

Daten über religiöse, weltanschauliche, politische oder gewerkschaftliche Ansichten oder Tätigkeiten,

2.

Daten über die Gesundheit, die Intimsphäre oder die Zugehörigkeit zu einer Rasse oder Ethnie,

3.

genetische Daten,

4.

biometrische Daten, die eine natürliche Person eindeutig identifizieren,

5.

Daten über verwaltungs- und strafrechtliche Verfolgungen oder Sanktionen,

6.

Daten über Massnahmen der sozialen Hilfe;

d.

_Bearbeiten__:_ jeder Umgang mit Personendaten, unabhängig von den angewandten Mitteln und Verfahren, insbesondere das Beschaffen, Speichern, Aufbewahren, Verwenden, Verändern, Bekanntgeben, Archivieren, Löschen oder Vernichten von Daten;

e.

_Bekanntgeben__:_ das Übermitteln oder Zugänglichmachen von Personendaten;

f.

_Profiling__:_ jede Art der automatisierten Bearbeitung von Personendaten, die darin besteht, dass diese Daten verwendet werden, um bestimmte persönliche Aspekte, die sich auf eine natürliche Person beziehen, zu bewerten, insbesondere um Aspekte bezüglich Arbeitsleistung, wirtschaftlicher Lage, Gesundheit, persönlicher Vorlieben, Interessen, Zuverlässigkeit, Verhalten, Aufenthaltsort oder Ortswechsel dieser natürlichen Person zu analysieren oder vorherzusagen;

g.

_Profiling mit hohem Risiko:_ Profiling, das ein hohes Risiko für die Persönlichkeit oder die Grundrechte der betroffenen Person mit sich bringt, indem es zu einer Verknüpfung von Daten führt, die eine Beurteilung wesentlicher Aspekte der Persönlichkeit einer natürlichen Person erlaubt;

h.

_Verletzung der Datensicherheit:_ eine Verletzung der Sicherheit, die dazu führt, dass Personendaten unbeabsichtigt oder widerrechtlich verlorengehen, gelöscht, vernichtet oder verändert werden oder Unbefugten offengelegt oder zugänglich gemacht werden;

i.

_Bundesorgan__:_ Behörde oder Dienststelle des Bundes oder Person, die mit öffentlichen Aufgaben des Bundes betraut ist;

j.

_Verantwortlicher__:_ private Person oder Bundesorgan, die oder das allein oder zusammen mit anderen über den Zweck und die Mittel der Bearbeitung entscheidet;

k.

_Auftragsbearbeiter__:_ private Person oder Bundesorgan, die oder das im Auftrag des Verantwortlichen Personendaten bearbeitet.

###### [**Art. 6** Grundsätze](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_6)

1 Personendaten müssen rechtmässig bearbeitet werden.

2 Die Bearbeitung muss nach Treu und Glauben erfolgen und verhältnismässig sein.

3 Personendaten dürfen nur zu einem bestimmten und für die betroffene Person erkennbaren Zweck beschafft werden; sie dürfen nur so bearbeitet werden, dass es mit diesem Zweck vereinbar ist.

4 Sie werden vernichtet oder anonymisiert, sobald sie zum Zweck der Bearbeitung nicht mehr erforderlich sind.

5 Wer Personendaten bearbeitet, muss sich über deren Richtigkeit vergewissern. Sie oder er muss alle angemessenen Massnahmen treffen, damit die Daten berichtigt, gelöscht oder vernichtet werden, die im Hinblick auf den Zweck ihrer Beschaffung oder Bearbeitung unrichtig oder unvollständig sind. Die Angemessenheit der Massnahmen hängt namentlich ab von der Art und dem Umfang der Bearbeitung sowie vom Risiko, das die Bearbeitung für die Persönlichkeit oder Grundrechte der betroffenen Personen mit sich bringt.

6 Ist die Einwilligung der betroffenen Person erforderlich, so ist diese Einwilligung nur gültig, wenn sie für eine oder mehrere bestimmte Bearbeitungen nach angemessener Information freiwillig erteilt wird.

7 Die Einwilligung muss ausdrücklich erfolgen für:

a.

die Bearbeitung von besonders schützenswerten Personendaten;

b.

ein Profiling mit hohem Risiko durch eine private Person; oder

c.

ein Profiling durch ein Bundesorgan.

###### [**Art. 7** Datenschutz durch Technik und datenschutzfreundliche Voreinstellungen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_7)

1 Der Verantwortliche ist verpflichtet, die Datenbearbeitung technisch und organisatorisch so auszugestalten, dass die Datenschutzvorschriften eingehalten werden, insbesondere die Grundsätze nach Artikel 6. Er berücksichtigt dies ab der Planung.

2 Die technischen und organisatorischen Massnahmen müssen insbesondere dem Stand der Technik, der Art und dem Umfang der Datenbearbeitung sowie dem Risiko, das die Bearbeitung für die Persönlichkeit oder die Grundrechte der betroffenen Personen mit sich bringt, angemessen sein.

3 Der Verantwortliche ist verpflichtet, mittels geeigneter Voreinstellungen sicherzustellen, dass die Bearbeitung der Personendaten auf das für den Verwendungszweck nötige Mindestmass beschränkt ist, soweit die betroffene Person nicht etwas anderes bestimmt.

###### [**Art. 8** Datensicherheit](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_8)

1 Der Verantwortliche und der Auftragsbearbeiter gewährleisten durch geeignete technische und organisatorische Massnahmen eine dem Risiko angemessene Datensicherheit.

2 Die Massnahmen müssen es ermöglichen, Verletzungen der Datensicherheit zu vermeiden.

3 Der Bundesrat erlässt Bestimmungen über die Mindestanforderungen an die Datensicherheit.

###### [**Art. 9** Bearbeitung durch Auftragsbearbeiter](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_9)

1 Die Bearbeitung von Personendaten kann vertraglich oder durch die Gesetzgebung einem Auftragsbearbeiter übertragen werden, wenn:

a.

die Daten so bearbeitet werden, wie der Verantwortliche selbst es tun dürfte; und

b.

keine gesetzliche oder vertragliche Geheimhaltungspflicht die Übertragung verbietet.

2 Der Verantwortliche muss sich insbesondere vergewissern, dass der Auftragsbearbeiter in der Lage ist, die Datensicherheit zu gewährleisten.

3 Der Auftragsbearbeiter darf die Bearbeitung nur mit vorgängiger Genehmigung des Verantwortlichen einem Dritten übertragen.

4 Er kann dieselben Rechtfertigungsgründe geltend machen wie der Verantwortliche.

###### [**Art. 10** Datenschutzberaterin oder -berater](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_10)

1 Private Verantwortliche können eine Datenschutzberaterin oder einen Datenschutzberater ernennen.

2 Die Datenschutzberaterin oder der Datenschutzberater ist Anlaufstelle für die betroffenen Personen und für die Behörden, die in der Schweiz für den Datenschutz zuständig sind. Sie oder er hat namentlich folgende Aufgaben:

a.

Schulung und Beratung des privaten Verantwortlichen in Fragen des Datenschutzes;

b.

Mitwirkung bei der Anwendung der Datenschutzvorschriften.

3 Private Verantwortliche können von der Ausnahme nach Artikel 23 Absatz 4 Gebrauch machen, wenn die folgenden Voraussetzungen erfüllt sind:

a.

Die Datenschutzberaterin oder der Datenschutzberater übt ihre oder seine Funktion gegenüber dem Verantwortlichen fachlich unabhängig und weisungsungebunden aus.

b.

Sie oder er übt keine Tätigkeiten aus, die mit ihren oder seinen Aufgaben als Datenschutzberaterin oder -berater unvereinbar sind.

c.

Sie oder er verfügt über die erforderlichen Fachkenntnisse.

d.

Der Verantwortliche veröffentlicht die Kontaktdaten der Datenschutzberaterin oder des Datenschutzberaters und teilt diese dem EDÖB mit.

4 Der Bundesrat regelt die Ernennung von Datenschutzberaterinnen und Datenschutzberatern durch die Bundesorgane.

###### [**Art. 11** Verhaltenskodizes](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_11)

1 Berufs-, Branchen- und Wirtschaftsverbände, die nach ihren Statuten zur Wahrung der wirtschaftlichen Interessen ihrer Mitglieder befugt sind, sowie Bundesorgane können dem EDÖB Verhaltenskodizes vorlegen.

2 Dieser nimmt zu den Verhaltenskodizes Stellung und veröffentlicht seine Stellungnahmen.

###### [**Art. 12** Verzeichnis der Bearbeitungstätigkeiten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_12)

1 Die Verantwortlichen und Auftragsbearbeiter führen je ein Verzeichnis ihrer Bearbeitungstätigkeiten.

2 Das Verzeichnis des Verantwortlichen enthält mindestens:

a.

die Identität des Verantwortlichen;

b.

den Bearbeitungszweck;

c.

eine Beschreibung der Kategorien betroffener Personen und der Kategorien bearbeiteter Personendaten;

d.

die Kategorien der Empfängerinnen und Empfänger;

e.

wenn möglich die Aufbewahrungsdauer der Personendaten oder die Kriterien zur Festlegung dieser Dauer;

f.

wenn möglich eine allgemeine Beschreibung der Massnahmen zur Gewährleistung der Datensicherheit nach Artikel 8;

g.

falls die Daten ins Ausland bekanntgegeben werden, die Angabe des Staates sowie die Garantien nach Artikel 16 Absatz 2.

3 Das Verzeichnis des Auftragsbearbeiters enthält Angaben zur Identität des Auftragsbearbeiters und des Verantwortlichen, zu den Kategorien von Bearbeitungen, die im Auftrag des Verantwortlichen durchgeführt werden, sowie die Angaben nach Absatz 2 Buchstaben f und g.

4 Die Bundesorgane melden ihre Verzeichnisse dem EDÖB.

5 Der Bundesrat sieht Ausnahmen für Unternehmen vor, die weniger als 250 Mitarbeiterinnen und Mitarbeiter beschäftigen und deren Datenbearbeitung ein geringes Risiko von Verletzungen der Persönlichkeit der betroffenen Personen mit sich bringt.

###### [**Art. 13** Zertifizierung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_13)

1 Die Hersteller von Datenbearbeitungssystemen oder -programmen sowie die Verantwortlichen und Auftragsbearbeiter können ihre Systeme, Produkte und Dienstleistungen einer Bewertung durch anerkannte unabhängige Zertifizierungsstellen unterziehen.

2 Der Bundesrat erlässt Vorschriften über die Anerkennung von Zertifizierungsverfahren und die Einführung eines Datenschutz-Qualitätszeichens. Er berücksichtigt dabei das internationale Recht und die international anerkannten technischen Normen.

## [2. Abschnitt: Datenbearbeitung durch private Verantwortliche mit Sitz oder Wohnsitz im Ausland](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_2/sec_2)

###### [**Art. 14** Vertretung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_14)

1 Private Verantwortliche mit Sitz oder Wohnsitz im Ausland bezeichnen eine Vertretung in der Schweiz, wenn sie Personendaten von Personen in der Schweiz bearbeiten und die Datenbearbeitung die folgenden Voraussetzungen erfüllt:

a.

Die Bearbeitung steht im Zusammenhang mit dem Angebot von Waren und Dienstleistungen oder der Beobachtung des Verhaltens von Personen in der Schweiz.

b.

Es handelt sich um eine umfangreiche Bearbeitung.

c.

Es handelt sich um eine regelmässige Bearbeitung.

d.

Die Bearbeitung bringt ein hohes Risiko für die Persönlichkeit der betroffenen Personen mit sich.

2 Die Vertretung dient als Anlaufstelle für die betroffenen Personen und den EDÖB.

3 Der Verantwortliche veröffentlicht den Namen und die Adresse der Vertretung.

###### [**Art. 15** Pflichten der Vertretung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_15)

1 Die Vertretung führt ein Verzeichnis der Bearbeitungstätigkeiten des Verantwortlichen, das die Angaben nach Artikel 12 Absatz 2 enthält.

2 Auf Anfrage teilt sie dem EDÖB die im Verzeichnis enthaltenen Angaben mit.

3 Auf Anfrage erteilt sie der betroffenen Person Auskünfte darüber, wie sie ihre Rechte ausüben kann.

## [3. Abschnitt: Bekanntgabe von Personendaten ins Ausland](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_2/sec_3)

###### [**Art. 16** Grundsätze](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_16)

1 Personendaten dürfen ins Ausland bekanntgegeben werden, wenn der Bundesrat festgestellt hat, dass die Gesetzgebung des betreffenden Staates oder das internationale Organ einen angemessenen Schutz gewährleistet.

2 Liegt kein Entscheid des Bundesrates nach Absatz 1 vor, so dürfen Personendaten ins Ausland bekanntgegeben werden, wenn ein geeigneter Datenschutz gewährleistet wird durch:

a.

einen völkerrechtlichen Vertrag;

b.

Datenschutzklauseln in einem Vertrag zwischen dem Verantwortlichen oder dem Auftragsbearbeiter und seiner Vertragspartnerin oder seinem Vertragspartner, die dem EDÖB vorgängig mitgeteilt wurden;

c.

spezifische Garantien, die das zuständige Bundesorgan erarbeitet und dem EDÖB vorgängig mitgeteilt hat;

d.

Standarddatenschutzklauseln, die der EDÖB vorgängig genehmigt, ausgestellt oder anerkannt hat; oder

e.

verbindliche unternehmensinterne Datenschutzvorschriften, die vorgängig vom EDÖB oder von einer für den Datenschutz zuständigen Behörde eines Staates, der einen angemessenen Schutz gewährleistet, genehmigt wurden.

3 Der Bundesrat kann andere geeignete Garantien im Sinne von Absatz 2 vorsehen.

###### [**Art. 17** Ausnahmen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_17)

1 Abweichend von Artikel 16 Absätze 1 und 2 dürfen in den folgenden Fällen Personendaten ins Ausland bekanntgegeben werden:

a.

Die betroffene Person hat ausdrücklich in die Bekanntgabe eingewilligt.

b.

Die Bekanntgabe steht in unmittelbarem Zusammenhang mit dem Abschluss oder der Abwicklung eines Vertrags:

1.

zwischen dem Verantwortlichen und der betroffenen Person; oder

2.

zwischen dem Verantwortlichen und seiner Vertragspartnerin oder seinem Vertragspartner im Interesse der betroffenen Person.

c.

Die Bekanntgabe ist notwendig für:

1.

die Wahrung eines überwiegenden öffentlichen Interesses; oder

2.

die Feststellung, Ausübung oder Durchsetzung von Rechtsansprüchen vor einem Gericht oder einer anderen zuständigen ausländischen Behörde.

d.

Die Bekanntgabe ist notwendig, um das Leben oder die körperliche Unversehrtheit der betroffenen Person oder eines Dritten zu schützen, und es ist nicht möglich, innerhalb einer angemessenen Frist die Einwilligung der betroffenen Person einzuholen.

e.

Die betroffene Person hat die Daten allgemein zugänglich gemacht und eine Bearbeitung nicht ausdrücklich untersagt.

f.

Die Daten stammen aus einem gesetzlich vorgesehenen Register, das öffentlich oder Personen mit einem schutzwürdigen Interesse zugänglich ist, soweit im Einzelfall die gesetzlichen Voraussetzungen der Einsichtnahme erfüllt sind.

2 Der Verantwortliche oder der Auftragsbearbeiter informiert den EDÖB auf Anfrage über die Bekanntgabe von Personendaten nach Absatz 1 Buchstaben b Ziffer 2, c und d.

###### [**Art. 18** Veröffentlichung von Personendaten in elektronischer Form](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_18)

Werden Personendaten zur Information der Öffentlichkeit mittels automatisierter Informations- und Kommunikationsdienste allgemein zugänglich gemacht, so gilt dies nicht als Bekanntgabe ins Ausland, auch wenn die Daten vom Ausland aus zugänglich sind.

# [3. Kapitel: Pflichten des Verantwortlichen und des Auftragsbearbeiters](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_3)

###### [**Art. 19** Informationspflicht bei der Beschaffung von Personendaten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_19)

1 Der Verantwortliche informiert die betroffene Person angemessen über die Beschaffung von Personendaten; diese Informationspflicht gilt auch, wenn die Daten nicht bei der betroffenen Person beschafft werden.

2 Er teilt der betroffenen Person bei der Beschaffung diejenigen Informationen mit, die erforderlich sind, damit sie ihre Rechte nach diesem Gesetz geltend machen kann und eine transparente Datenbearbeitung gewährleistet ist; er teilt ihr mindestens mit:

a.

die Identität und die Kontaktdaten des Verantwortlichen;

b.

den Bearbeitungszweck;

c.

gegebenenfalls die Empfängerinnen und Empfänger oder die Kategorien von Empfängerinnen und Empfängern, denen Personendaten bekanntgegeben werden.

3 Werden die Daten nicht bei der betroffenen Person beschafft, so teilt er ihr zudem die Kategorien der bearbeiteten Personendaten mit.

4 Werden die Personendaten ins Ausland bekanntgegeben, so teilt er der betroffenen Person auch den Staat oder das internationale Organ und gegebenenfalls die Garantien nach Artikel 16 Absatz 2 oder die Anwendung einer Ausnahme nach Artikel 17 mit.

5 Werden die Daten nicht bei der betroffenen Person beschafft, so teilt er ihr die Informationen nach den Absätzen 2–4 spätestens einen Monat, nachdem er die Daten erhalten hat, mit. Gibt der Verantwortliche die Personendaten vor Ablauf dieser Frist bekannt, so informiert er die betroffene Person spätestens im Zeitpunkt der Bekanntgabe.

###### [**Art. 20** Ausnahmen von der Informationspflicht und Einschränkungen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_20)

1 Die Informationspflicht nach Artikel 19 entfällt, wenn eine der folgenden Voraussetzungen erfüllt ist:

a.

Die betroffene Person verfügt bereits über die entsprechenden Informationen.

b.

Die Bearbeitung ist gesetzlich vorgesehen.

c.

Es handelt sich beim Verantwortlichen um eine private Person, die gesetzlich zur Geheimhaltung verpflichtet ist.

d.

Die Voraussetzungen nach Artikel 27 sind erfüllt.

2 Werden die Personendaten nicht bei der betroffenen Person beschafft, so entfällt die Informationspflicht zudem, wenn eine der folgenden Voraussetzungen erfüllt ist:

a.

Die Information ist nicht möglich.

b.

Die Information erfordert einen unverhältnismässigen Aufwand.

3 Der Verantwortliche kann die Mitteilung der Informationen in den folgenden Fällen einschränken, aufschieben oder darauf verzichten:

a.

Überwiegende Interessen Dritter erfordern die Massnahme.

b.

Die Information vereitelt den Zweck der Bearbeitung.

c.

Der Verantwortliche ist eine private Person und die folgenden Voraussetzungen sind erfüllt:

1.

Überwiegende Interessen des Verantwortlichen erfordern die Massnahme.

2.

Der Verantwortliche gibt die Personendaten nicht Dritten bekannt.

d.

Der Verantwortliche ist ein Bundesorgan und eine der folgenden Voraussetzungen ist erfüllt:

1.

Die Massnahme ist wegen überwiegender öffentlicher Interessen, insbesondere der inneren oder der äusseren Sicherheit der Schweiz, erforderlich.

2.

Die Mitteilung der Information kann eine Ermittlung, eine Untersuchung oder ein behördliches oder gerichtliches Verfahren gefährden.

4 Unternehmen, die zum selben Konzern gehören, gelten nicht als Dritte im Sinne von Absatz 3 Buchstabe c Ziffer 2.

###### [**Art. 21** Informationspflicht bei einer automatisierten Einzelentscheidung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_21)

1 Der Verantwortliche informiert die betroffene Person über eine Entscheidung, die ausschliesslich auf einer automatisierten Bearbeitung beruht und die für sie mit einer Rechtsfolge verbunden ist oder sie erheblich beeinträchtigt (automatisierte Einzelentscheidung).

2 Er gibt der betroffenen Person auf Antrag die Möglichkeit, ihren Standpunkt darzulegen. Die betroffene Person kann verlangen, dass die automatisierte Einzelentscheidung von einer natürlichen Person überprüft wird.

3 Die Absätze 1 und 2 gelten nicht, wenn:

a.

die automatisierte Einzelentscheidung in unmittelbarem Zusammenhang mit dem Abschluss oder der Abwicklung eines Vertrags zwischen dem Verantwortlichen und der betroffenen Person steht und ihrem Begehren stattgegeben wird; oder

b.

die betroffene Person ausdrücklich eingewilligt hat, dass die Entscheidung automatisiert erfolgt.

4 Ergeht die automatisierte Einzelentscheidung durch ein Bundesorgan, so muss es die Entscheidung entsprechend kennzeichnen. Absatz 2 ist nicht anwendbar, wenn die betroffene Person nach Artikel 30 Absatz 2 des Verwaltungsverfahrensgesetzes vom 20. Dezember 1968[6](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e743) (VwVG) oder nach einem anderen Bundesgesetz vor dem Entscheid nicht angehört werden muss.

[6](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e743) [SR **172.021**](https://www.fedlex.admin.ch/eli/cc/1969/737_757_755/de)

###### [**Art. 22** Datenschutz-Folgenabschätzung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_22)

1 Der Verantwortliche erstellt vorgängig eine Datenschutz-Folgenabschätzung, wenn eine Bearbeitung ein hohes Risiko für die Persönlichkeit oder die Grundrechte der betroffenen Person mit sich bringen kann. Sind mehrere ähnliche Bearbeitungsvorgänge geplant, so kann eine gemeinsame Abschätzung erstellt werden.

2 Das hohe Risiko ergibt sich, insbesondere bei Verwendung neuer Technologien, aus der Art, dem Umfang, den Umständen und dem Zweck der Bearbeitung. Es liegt namentlich vor:

a.

bei der umfangreichen Bearbeitung besonders schützenswerter Personendaten;

b.

wenn systematisch umfangreiche öffentliche Bereiche überwacht werden.

3 Die Datenschutz-Folgenabschätzung enthält eine Beschreibung der geplanten Bearbeitung, eine Bewertung der Risiken für die Persönlichkeit oder die Grundrechte der betroffenen Person sowie die Massnahmen zum Schutz der Persönlichkeit und der Grundrechte.

4 Von der Erstellung einer Datenschutz-Folgenabschätzung ausgenommen sind private Verantwortliche, wenn sie gesetzlich zur Bearbeitung der Daten verpflichtet sind.

5 Der private Verantwortliche kann von der Erstellung einer Datenschutz-Folgenabschätzung absehen, wenn er ein System, ein Produkt oder eine Dienstleistung einsetzt, das oder die für die vorgesehene Verwendung nach Artikel 13 zertifiziert ist, oder wenn er einen Verhaltenskodex nach Artikel 11 einhält, der die folgenden Voraussetzungen erfüllt:

a.

Der Verhaltenskodex beruht auf einer Datenschutz-Folgenabschätzung.

b.

Er sieht Massnahmen zum Schutz der Persönlichkeit und der Grundrechte der betroffenen Person vor.

c.

Er wurde dem EDÖB vorgelegt.

###### [**Art. 23** Konsultation des EDÖB](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_23)

1 Ergibt sich aus der Datenschutz-Folgenabschätzung, dass die geplante Bearbeitung trotz der vom Verantwortlichen vorgesehenen Massnahmen noch ein hohes Risiko für die Persönlichkeit oder die Grundrechte der betroffenen Person zur Folge hat, so holt er vorgängig die Stellungnahme des EDÖB ein.

2 Der EDÖB teilt dem Verantwortlichen innerhalb von zwei Monaten seine Einwände gegen die geplante Bearbeitung mit. Diese Frist kann um einen Monat verlängert werden, wenn es sich um eine komplexe Datenbearbeitung handelt.

3 Hat der EDÖB Einwände gegen die geplante Bearbeitung, so schlägt er dem Verantwortlichen geeignete Massnahmen vor.

4 Der private Verantwortliche kann von der Konsultation des EDÖB absehen, wenn er die Datenschutzberaterin oder den Datenschutzberater nach Artikel 10 konsultiert hat.

###### [**Art. 24** Meldung von Verletzungen der Datensicherheit](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_24)

1 Der Verantwortliche meldet dem EDÖB so rasch als möglich eine Verletzung der Datensicherheit, die voraussichtlich zu einem hohen Risiko für die Persönlichkeit oder die Grundrechte der betroffenen Person führt.

2 In der Meldung nennt er mindestens die Art der Verletzung der Datensicherheit, deren Folgen und die ergriffenen oder vorgesehenen Massnahmen.

3 Der Auftragsbearbeiter meldet dem Verantwortlichen so rasch als möglich eine Verletzung der Datensicherheit.

4 Der Verantwortliche informiert die betroffene Person, wenn es zu ihrem Schutz erforderlich ist oder der EDÖB es verlangt.

5 Er kann die Information an die betroffene Person einschränken, aufschieben oder darauf verzichten, wenn:

a.

ein Grund nach Artikel 26 Absatz 1 Buchstabe b oder Absatz 2 Buchstabe b vorliegt oder eine gesetzliche Geheimhaltungspflicht dies verbietet;

b.

die Information unmöglich ist oder einen unverhältnismässigen Aufwand erfordert; oder

c.

die Information der betroffenen Person durch eine öffentliche Bekanntmachung in vergleichbarer Weise sichergestellt ist.

6 Eine Meldung, die aufgrund dieses Artikels erfolgt, darf in einem Strafverfahren gegen die meldepflichtige Person nur mit deren Einverständnis verwendet werden.

# [4. Kapitel: Rechte der betroffenen Person](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_4)

###### [**Art. 25** Auskunftsrecht](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_25)

1 Jede Person kann vom Verantwortlichen Auskunft darüber verlangen, ob Personendaten über sie bearbeitet werden.

2 Die betroffene Person erhält diejenigen Informationen, die erforderlich sind, damit sie ihre Rechte nach diesem Gesetz geltend machen kann und eine transparente Datenbearbeitung gewährleistet ist. In jedem Fall werden ihr folgende Informationen mitgeteilt:

a.

die Identität und die Kontaktdaten des Verantwortlichen;

b.

die bearbeiteten Personendaten als solche;

c.

der Bearbeitungszweck;

d.

die Aufbewahrungsdauer der Personendaten oder, falls dies nicht möglich ist, die Kriterien zur Festlegung dieser Dauer;

e.

die verfügbaren Angaben über die Herkunft der Personendaten, soweit sie nicht bei der betroffenen Person beschafft wurden;

f.

gegebenenfalls das Vorliegen einer automatisierten Einzelentscheidung sowie die Logik, auf der die Entscheidung beruht;

g.

gegebenenfalls die Empfängerinnen und Empfänger oder die Kategorien von Empfängerinnen und Empfängern, denen Personendaten bekanntgegeben werden, sowie die Informationen nach Artikel 19 Absatz 4.

3 Personendaten über die Gesundheit können der betroffenen Person mit ihrer Einwilligung durch eine von ihr bezeichnete Gesundheitsfachperson mitgeteilt werden.

4 Lässt der Verantwortliche Personendaten von einem Auftragsbearbeiter bearbeiten, so bleibt er auskunftspflichtig.

5 Niemand kann im Voraus auf das Auskunftsrecht verzichten.

6 Der Verantwortliche muss kostenlos Auskunft erteilen. Der Bundesrat kann Ausnahmen vorsehen, namentlich wenn der Aufwand unverhältnismässig ist.

7 Die Auskunft wird in der Regel innerhalb von 30 Tagen erteilt.

###### [**Art. 26** Einschränkungen des Auskunftsrechts](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_26)

1 Der Verantwortliche kann die Auskunft verweigern, einschränken oder aufschieben, wenn:

a.

ein Gesetz im formellen Sinn dies vorsieht, namentlich um ein Berufsgeheimnis zu schützen;

b.

dies aufgrund überwiegender Interessen Dritter erforderlich ist; oder

c.

das Auskunftsgesuch offensichtlich unbegründet ist, namentlich wenn es einen datenschutzwidrigen Zweck verfolgt, oder offensichtlich querulatorisch ist.

2 Darüber hinaus ist es in den folgenden Fällen möglich, die Auskunft zu verweigern, einzuschränken oder aufzuschieben:

a.

Der Verantwortliche ist eine private Person und die folgenden Voraussetzungen sind erfüllt:

1.

Überwiegende Interessen des Verantwortlichen erfordern die Massnahme.

2.

Der Verantwortliche gibt die Personendaten nicht Dritten bekannt.

b.

Der Verantwortliche ist ein Bundesorgan, und eine der folgenden Voraussetzungen ist erfüllt:

1.

Die Massnahme ist wegen überwiegender öffentlicher Interessen, insbesondere der inneren oder der äusseren Sicherheit der Schweiz, erforderlich.

2.

Die Mitteilung der Information kann eine Ermittlung, eine Untersuchung oder ein behördliches oder gerichtliches Verfahren gefährden.

3 Unternehmen, die zum selben Konzern gehören, gelten nicht als Dritte im Sinne von Absatz 2 Buchstabe a Ziffer 2.

4 Der Verantwortliche muss angeben, weshalb er die Auskunft verweigert, einschränkt oder aufschiebt.

###### [**Art. 27** Einschränkungen des Auskunftsrechts für Medien](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_27)

1 Werden Personendaten ausschliesslich zur Veröffentlichung im redaktionellen Teil eines periodisch erscheinenden Mediums bearbeitet, so kann der Verantwortliche aus einem der folgenden Gründe die Auskunft verweigern, einschränken oder aufschieben:

a.

Die Daten geben Aufschluss über die Informationsquellen.

b.

Durch die Auskunft würde Einsicht in Entwürfe für Publikationen gewährt.

c.

Die Veröffentlichung würde die freie Meinungsbildung des Publikums gefährden.

2 Medienschaffende können die Auskunft zudem verweigern, einschränken oder aufschieben, wenn ihnen die Personendaten ausschliesslich als persönliches Arbeitsinstrument dienen.

###### [**Art. 28** Recht auf Datenherausgabe oder -übertragung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_28)

1 Jede Person kann vom Verantwortlichen die Herausgabe ihrer Personendaten, die sie ihm bekanntgegeben hat, in einem gängigen elektronischen Format verlangen, wenn:

a.

der Verantwortliche die Daten automatisiert bearbeitet; und

b.

die Daten mit der Einwilligung der betroffenen Person oder in unmittelbarem Zusammenhang mit dem Abschluss oder der Abwicklung eines Vertrags zwischen dem Verantwortlichen und der betroffenen Person bearbeitet werden.

2 Die betroffene Person kann zudem vom Verantwortlichen verlangen, dass er ihre Personendaten einem anderen Verantwortlichen überträgt, wenn die Voraussetzungen nach Absatz 1 erfüllt sind und dies keinen unverhältnismässigen Aufwand erfordert.

3 Der Verantwortliche muss die Personendaten kostenlos herausgeben oder übertragen. Der Bundesrat kann Ausnahmen vorsehen, namentlich wenn der Aufwand unverhältnismässig ist.

###### [**Art. 29** Einschränkungen des Rechts auf Datenherausgabe oder -übertragung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_29)

1 Der Verantwortliche kann die Herausgabe oder Übertragung der Personendaten aus den in Artikel 26 Absätze 1 und 2 aufgeführten Gründen verweigern, einschränken oder aufschieben.

2 Der Verantwortliche muss angeben, weshalb er die Herausgabe oder Übertragung verweigert, einschränkt oder aufschiebt.

# [5. Kapitel: Besondere Bestimmungen zur Datenbearbeitung durch private Personen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_5)

###### [**Art. 30** Persönlichkeitsverletzungen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_30)

1 Wer Personendaten bearbeitet, darf die Persönlichkeit der betroffenen Personen nicht widerrechtlich verletzen.

2 Eine Persönlichkeitsverletzung liegt insbesondere vor, wenn:

a.

Personendaten entgegen den Grundsätzen nach den Artikeln 6 und 8 bearbeitet werden;

b.

Personendaten entgegen der ausdrücklichen Willenserklärung der betroffenen Person bearbeitet werden;

c.

Dritten besonders schützenswerte Personendaten bekanntgegeben werden.

3 In der Regel liegt keine Persönlichkeitsverletzung vor, wenn die betroffene Person die Personendaten allgemein zugänglich gemacht und eine Bearbeitung nicht ausdrücklich untersagt hat.

###### [**Art. 31** Rechtfertigungsgründe](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_31)

1 Eine Persönlichkeitsverletzung ist widerrechtlich, wenn sie nicht durch Einwilligung der betroffenen Person, durch ein überwiegendes privates oder öffentliches Interesse oder durch Gesetz gerechtfertigt ist.

2 Ein überwiegendes Interesse des Verantwortlichen fällt insbesondere in folgenden Fällen in Betracht:

a.

Der Verantwortliche bearbeitet die Personendaten über die Vertragspartnerin oder den Vertragspartner in unmittelbarem Zusammenhang mit dem Abschluss oder der Abwicklung eines Vertrags.

b.

Der Verantwortliche steht mit einer anderen Person in wirtschaftlichem Wettbewerb oder wird in wirtschaftlichen Wettbewerb treten und bearbeitet zu diesem Zweck Personendaten, die Dritten nicht bekanntgegeben werden; nicht als Dritte im Rahmen dieser Bestimmung gelten Unternehmen, die zum selben Konzern gehören wie der Verantwortliche.

c.

Der Verantwortliche bearbeitet Personendaten zur Prüfung der Kreditwürdigkeit der betroffenen Person, wobei die folgenden Voraussetzungen erfüllt sind:

1.

Es handelt sich weder um besonders schützenswerte Personendaten noch um ein Profiling mit hohem Risiko.

2.

Die Daten werden Dritten nur bekanntgegeben, wenn diese die Daten für den Abschluss oder die Abwicklung eines Vertrags mit der betroffenen Person benötigen.

3.

Die Daten sind nicht älter als zehn Jahre.

4.

Die betroffene Person ist volljährig.

d.

Der Verantwortliche bearbeitet die Personendaten beruflich und ausschliesslich zur Veröffentlichung im redaktionellen Teil eines periodisch erscheinenden Mediums oder die Daten dienen ihm, falls keine Veröffentlichung erfolgt, ausschliesslich als persönliches Arbeitsinstrument.

e.

Der Verantwortliche bearbeitet die Personendaten für nicht personenbezogene Zwecke, insbesondere für Forschung, Planung oder Statistik, wobei die folgenden Voraussetzungen erfüllt sind:

1.

Er anonymisiert die Daten, sobald der Bearbeitungszweck dies erlaubt; ist eine Anonymisierung unmöglich oder erfordert sie einen unverhältnismässigen Aufwand, so trifft er angemessene Massnahmen, um die Bestimmbarkeit der betroffenen Person zu verhindern.

2.

Handelt es sich um besonders schützenswerte Personendaten, so gibt er diese Dritten so bekannt, dass die betroffene Person nicht bestimmbar ist; ist dies nicht möglich, so muss gewährleistet sein, dass die Dritten die Daten nur zu nicht personenbezogenen Zwecken bearbeiten.

3.

Die Ergebnisse werden so veröffentlicht, dass die betroffenen Personen nicht bestimmbar sind.

f.

Der Verantwortliche sammelt Personendaten über eine Person des öffentlichen Lebens, die sich auf das Wirken dieser Person in der Öffentlichkeit beziehen.

###### [**Art. 32** Rechtsansprüche](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_32)

1 Die betroffene Person kann verlangen, dass unrichtige Personendaten berichtigt werden, es sei denn:

a.

eine gesetzliche Vorschrift verbietet die Änderung;

b.

die Personendaten werden zu Archivzwecken im öffentlichen Interesse bearbeitet.

2 Klagen zum Schutz der Persönlichkeit richten sich nach den Artikeln 28, 28_a_ sowie 28_g_–28_l_ des Zivilgesetzbuchs[7](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1148). Die klagende Partei kann insbesondere verlangen, dass:

a.

eine bestimmte Datenbearbeitung verboten wird;

b.

eine bestimmte Bekanntgabe von Personendaten an Dritte untersagt wird;

c.

Personendaten gelöscht oder vernichtet werden.

3 Kann weder die Richtigkeit noch die Unrichtigkeit der betreffenden Personendaten festgestellt werden, so kann die klagende Partei verlangen, dass ein Bestreitungsvermerk angebracht wird.

4 Die klagende Partei kann zudem verlangen, dass die Berichtigung, die Löschung oder die Vernichtung, das Verbot der Bearbeitung oder der Bekanntgabe an Dritte, der Bestreitungsvermerk oder das Urteil Dritten mitgeteilt oder veröffentlicht wird.

[7](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1148) [SR **210**](https://www.fedlex.admin.ch/eli/cc/24/233_245_233/de)

# [6. Kapitel: Besondere Bestimmungen zur Datenbearbeitung durch Bundesorgane](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_6)

###### [**Art. 33** Kontrolle und Verantwortung bei gemeinsamer Bearbeitung von Personendaten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_33)

Der Bundesrat regelt die Kontrollverfahren und die Verantwortung für den Datenschutz, wenn ein Bundesorgan Personendaten zusammen mit anderen Bundesorganen, mit kantonalen Organen oder mit privaten Personen bearbeitet.

###### [**Art. 34** Rechtsgrundlagen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_34)

1 Bundesorgane dürfen Personendaten nur bearbeiten, wenn dafür eine gesetzliche Grundlage besteht.

2 Eine Grundlage in einem Gesetz im formellen Sinn ist in folgenden Fällen erforderlich:

a.

Es handelt sich um die Bearbeitung von besonders schützenswerten Personendaten.

b.

Es handelt sich um ein Profiling.

c.

Der Bearbeitungszweck oder die Art und Weise der Datenbearbeitung können zu einem schwerwiegenden Eingriff in die Grundrechte der betroffenen Person führen.

3 Für die Bearbeitung von Personendaten nach Absatz 2 Buchstaben a und b ist eine Grundlage in einem Gesetz im materiellen Sinn ausreichend, wenn die folgenden Voraussetzungen erfüllt sind:

a.

Die Bearbeitung ist für eine in einem Gesetz im formellen Sinn festgelegte Aufgabe unentbehrlich.

b.

Der Bearbeitungszweck birgt für die Grundrechte der betroffenen Person keine besonderen Risiken.

4 In Abweichung von den Absätzen 1–3 dürfen Bundesorgane Personendaten bearbeiten, wenn eine der folgenden Voraussetzungen erfüllt ist:

a.

Der Bundesrat hat die Bearbeitung bewilligt, weil er die Rechte der betroffenen Person für nicht gefährdet hält.

b.

Die betroffene Person hat im Einzelfall in die Bearbeitung eingewilligt oder hat ihre Personendaten allgemein zugänglich gemacht und eine Bearbeitung nicht ausdrücklich untersagt.

c.

Die Bearbeitung ist notwendig, um das Leben oder die körperliche Unversehrtheit der betroffenen Person oder eines Dritten zu schützen, und es ist nicht möglich, innerhalb einer angemessenen Frist die Einwilligung der betroffenen Person einzuholen.

###### [**Art. 35** Automatisierte Datenbearbeitung im Rahmen von Pilotversuchen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_35)

1 Der Bundesrat kann vor Inkrafttreten eines Gesetzes im formellen Sinn die automatisierte Bearbeitung von besonders schützenswerten Personendaten oder andere Datenbearbeitungen nach Artikel 34 Absatz 2 Buchstaben b und c bewilligen, wenn:

a.

die Aufgaben, aufgrund deren die Bearbeitung erforderlich ist, in einem bereits in Kraft stehenden Gesetz im formellen Sinn geregelt sind;

b.

ausreichende Massnahmen getroffen werden, um einen Eingriff in die Grundrechte der betroffenen Personen auf das Mindestmass zu begrenzen; und

c.

für die praktische Umsetzung der Datenbearbeitung eine Testphase vor dem Inkrafttreten, insbesondere aus technischen Gründen, unentbehrlich ist.

2 Er holt vorgängig die Stellungnahme des EDÖB ein.

3 Das zuständige Bundesorgan legt dem Bundesrat spätestens zwei Jahre nach der Aufnahme des Pilotversuchs einen Evaluationsbericht vor. Es schlägt darin die Fortführung oder die Einstellung der Bearbeitung vor.

4 Die automatisierte Datenbearbeitung muss in jedem Fall abgebrochen werden, wenn innerhalb von fünf Jahren nach Aufnahme des Pilotversuchs kein Gesetz im formellen Sinn in Kraft getreten ist, das die erforderliche Rechtsgrundlage enthält.

###### [**Art. 36** Bekanntgabe von Personendaten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_36)

1 Bundesorgane dürfen Personendaten nur bekanntgeben, wenn dafür eine gesetzliche Grundlage nach Artikel 34 Absätze 1–3 besteht.

2 Sie dürfen Personendaten in Abweichung von Absatz 1 im Einzelfall bekanntgeben, wenn eine der folgenden Voraussetzungen erfüllt ist:

a.

Die Bekanntgabe der Daten ist für den Verantwortlichen oder für die Empfängerin oder den Empfänger zur Erfüllung einer gesetzlichen Aufgabe unentbehrlich.

b.

Die betroffene Person hat in die Bekanntgabe eingewilligt.

c.

Die Bekanntgabe der Daten ist notwendig, um das Leben oder die körperliche Unversehrtheit der betroffenen Person oder eines Dritten zu schützen, und es ist nicht möglich, innerhalb einer angemessenen Frist die Einwilligung der betroffenen Person einzuholen.

d.

Die betroffene Person hat ihre Daten allgemein zugänglich gemacht und eine Bekanntgabe nicht ausdrücklich untersagt.

e.

Die Empfängerin oder der Empfänger macht glaubhaft, dass die betroffene Person die Einwilligung verweigert oder Widerspruch gegen die Bekanntgabe einlegt, um ihr oder ihm die Durchsetzung von Rechtsansprüchen oder die Wahrnehmung anderer schutzwürdiger Interessen zu verwehren; der betroffenen Person ist vorgängig Gelegenheit zur Stellungnahme zu geben, es sei denn, dies ist unmöglich oder mit unverhältnismässigem Aufwand verbunden.

3 Die Bundesorgane dürfen Personendaten darüber hinaus im Rahmen der behördlichen Information der Öffentlichkeit von Amtes wegen oder gestützt auf das Öffentlichkeitsgesetz vom 17. Dezember 2004[8](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1287) bekanntgeben, wenn:

a.

die Daten im Zusammenhang mit der Erfüllung öffentlicher Aufgaben stehen; und

b.

an der Bekanntgabe ein überwiegendes öffentliches Interesse besteht.

4 Sie dürfen Name, Vorname, Adresse und Geburtsdatum einer Person auf Anfrage auch bekanntgeben, wenn die Voraussetzungen nach Absatz 1 oder 2 nicht erfüllt sind.

5 Sie dürfen Personendaten mittels automatisierter Informations- und Kommunikationsdienste allgemein zugänglich machen, wenn eine Rechtsgrundlage die Veröffentlichung dieser Daten vorsieht oder wenn sie Daten gestützt auf Absatz 3 bekanntgeben. Besteht kein öffentliches Interesse mehr daran, die Daten allgemein zugänglich zu machen, so werden die betreffenden Daten aus dem automatisierten Informations- und Kommunikationsdienst gelöscht.

6 Die Bundesorgane lehnen die Bekanntgabe ab, schränken sie ein oder verbinden sie mit Auflagen, wenn:

a.

wesentliche öffentliche Interessen oder offensichtlich schutzwürdige Interessen der betroffenen Person es verlangen; oder

b.

gesetzliche Geheimhaltungspflichten oder besondere Datenschutzvorschriften es verlangen.

[8](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1287) [SR **152.3**](https://www.fedlex.admin.ch/eli/cc/2006/355/de)

###### [**Art. 37** Widerspruch gegen die Bekanntgabe von Personendaten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_37)

1 Die betroffene Person, die ein schutzwürdiges Interesse glaubhaft macht, kann gegen die Bekanntgabe bestimmter Personendaten durch das verantwortliche Bundesorgan Widerspruch einlegen.

2 Das Bundesorgan weist das Begehren ab, wenn eine der folgenden Voraussetzungen erfüllt ist:

a.

Es besteht eine Rechtspflicht zur Bekanntgabe.

b.

Die Erfüllung seiner Aufgaben wäre sonst gefährdet.

3 Artikel 36 Absatz 3 bleibt vorbehalten.

###### [**Art. 38** Angebot von Unterlagen an das Bundesarchiv](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_38)

1 In Übereinstimmung mit dem Archivierungsgesetz vom 26. Juni 1998[9](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1350) bieten die Bundesorgane dem Bundesarchiv alle Personendaten an, die sie nicht mehr ständig benötigen.

2 Sie vernichten die vom Bundesarchiv als nicht archivwürdig bezeichneten Personendaten, es sei denn:

a.

diese werden anonymisiert;

b.

diese müssen zu Beweis- oder Sicherheitszwecken oder zur Wahrung der schutzwürdigen Interessen der betroffenen Person aufbewahrt werden.

[9](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1350) [SR **152.1**](https://www.fedlex.admin.ch/eli/cc/1999/354/de)

###### [**Art. 39** Datenbearbeitung für nicht personenbezogene Zwecke](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_39)

1 Bundesorgane dürfen Personendaten für nicht personenbezogene Zwecke, insbesondere für Forschung, Planung oder Statistik, bearbeiten, wenn:

a.

die Daten anonymisiert werden, sobald der Bearbeitungszweck dies erlaubt;

b.

das Bundesorgan privaten Personen besonders schützenswerte Personendaten nur so bekanntgibt, dass die betroffenen Personen nicht bestimmbar sind;

c.

die Empfängerin oder der Empfänger Dritten die Daten nur mit der Zustimmung des Bundesorgans weitergibt, das die Daten bekanntgegeben hat; und

d.

die Ergebnisse nur so veröffentlicht werden, dass die betroffenen Personen nicht bestimmbar sind.

2 Die Artikel 6 Absatz 3, 34 Absatz 2 sowie 36 Absatz 1 sind nicht anwendbar.

###### [**Art. 40** Privatrechtliche Tätigkeit von Bundesorganen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_40)

Handelt ein Bundesorgan privatrechtlich, so gelten die Bestimmungen für die Datenbearbeitung durch private Personen.

###### [**Art. 41** Ansprüche und Verfahren](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_41)

1 Wer ein schutzwürdiges Interesse hat, kann vom verantwortlichen Bundesorgan verlangen, dass es:

a.

die widerrechtliche Bearbeitung der betreffenden Personendaten unterlässt;

b.

die Folgen einer widerrechtlichen Bearbeitung beseitigt;

c.

die Widerrechtlichkeit der Bearbeitung feststellt.

2 Die Gesuchstellerin oder der Gesuchsteller kann insbesondere verlangen, dass das Bundesorgan:

a.

die betreffenden Personendaten berichtigt, löscht oder vernichtet;

b.

seinen Entscheid, namentlich über die Berichtigung, Löschung oder Vernichtung, den Widerspruch gegen die Bekanntgabe nach Artikel 37 oder den Bestreitungsvermerk nach Absatz 4 Dritten mitteilt oder veröffentlicht.

3 Statt die Personendaten zu löschen oder zu vernichten, schränkt das Bundesorgan die Bearbeitung ein, wenn:

a.

die betroffene Person die Richtigkeit der Personendaten bestreitet und weder die Richtigkeit noch die Unrichtigkeit festgestellt werden kann;

b.

überwiegende Interessen Dritter dies erfordern;

c.

ein überwiegendes öffentliches Interesse, namentlich die innere oder die äussere Sicherheit der Schweiz, dies erfordert;

d.

die Löschung oder Vernichtung der Daten eine Ermittlung, eine Untersuchung oder ein behördliches oder gerichtliches Verfahren gefährden kann.

4 Kann weder die Richtigkeit noch die Unrichtigkeit der betreffenden Personendaten festgestellt werden, so bringt das Bundesorgan bei den Daten einen Bestreitungsvermerk an.

5 Die Berichtigung, Löschung oder Vernichtung von Personendaten kann nicht verlangt werden in Bezug auf die Bestände öffentlich zugänglicher Bibliotheken, Bildungseinrichtungen, Museen, Archive oder anderer öffentlicher Gedächtnisinstitutionen. Macht die Gesuchstellerin oder der Gesuchsteller ein überwiegendes Interesse glaubhaft, so kann sie oder er verlangen, dass die Institution den Zugang zu den umstrittenen Daten beschränkt. Die Absätze 3 und 4 sind nicht anwendbar.

6 Das Verfahren richtet sich nach dem VwVG[10](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1456). Die Ausnahmen nach den Artikeln 2 und 3 VwVG sind nicht anwendbar.

[10](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1456) [SR **172.021**](https://www.fedlex.admin.ch/eli/cc/1969/737_757_755/de)

###### [**Art. 42** Verfahren im Falle der Bekanntgabe von amtlichen Dokumenten, die Personendaten enthalten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_42)

Ist ein Verfahren betreffend den Zugang zu amtlichen Dokumenten, die Personendaten enthalten, im Sinne des Öffentlichkeitsgesetzes vom 17. Dezember 2004[11](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1473) hängig, so kann die betroffene Person in diesem Verfahren diejenigen Rechte geltend machen, die ihr nach Artikel 41 des vorliegenden Gesetzes bezogen auf diejenigen Dokumente zustehen, die Gegenstand des Zugangsverfahrens sind.

[11](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1473) [SR **152.3**](https://www.fedlex.admin.ch/eli/cc/2006/355/de)

# [7. Kapitel: Eidgenössischer Datenschutz- und Öffentlichkeitsbeauftragter](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_7)

## [1. Abschnitt: Organisation](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_7/sec_1)

###### [**Art. 43** Wahl und Stellung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_43)

1 Die Vereinigte Bundesversammlung wählt die Leiterin oder den Leiter des EDÖB (die oder der Beauftragte).

2 Wählbar ist, wer in eidgenössischen Angelegenheiten stimmberechtigt ist.

3 Das Arbeitsverhältnis der oder des Beauftragten richtet sich, soweit dieses Gesetz nichts anderes vorsieht, nach dem Bundespersonalgesetz vom 24. März 2000[12](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1513) (BPG). Die oder der Beauftragte ist bis zum vollendeten 65. Altersjahr bei der Pensionskasse des Bundes PUBLICA gegen die wirtschaftlichen Folgen von Alter, Invalidität und Tod versichert. Wird das Arbeitsverhältnis nach dem vollendeten 65. Altersjahr fortgesetzt, so wird auf Verlangen der oder des Beauftragten die Altersvorsorge bis zur Beendigung des Arbeitsverhältnisses, höchstens aber bis zum Ende des Jahres, in dem sie oder er das 68. Altersjahr vollendet, weitergeführt. Der EDÖB finanziert die Sparbeiträge des Arbeitsgebers.[13](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1522)

3bis Die Bundesversammlung erlässt die Ausführungsbestimmungen über das Arbeitsverhältnis der oder des Beauftragten in einer Verordnung.[14](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1543)

4 Die oder der Beauftragte übt ihre oder seine Funktion unabhängig aus, ohne Weisungen einer Behörde oder eines Dritten einzuholen oder entgegenzunehmen. Sie oder er ist administrativ der Bundeskanzlei zugeordnet.

5 Sie oder er verfügt über ein ständiges Sekretariat und ein eigenes Budget. Sie oder er stellt sein Personal an.

6 Sie oder er untersteht nicht dem Beurteilungssystem nach Artikel 4 Absatz 3 BPG.

[12](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1513) [SR **172.220.1**](https://www.fedlex.admin.ch/eli/cc/2001/123/de)

[13](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1522) Zweiter bis vierter Satz eingefügt durch Ziff. I des BG vom 17. Juni 2022 (Arbeitsverhältnis der Leiterin oder des Leiters des Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten), in Kraft seit 1. Sept. 2023 ([AS **2023** 231](https://www.fedlex.admin.ch/eli/oc/2023/231/de); [BBl **2022** 345](https://www.fedlex.admin.ch/eli/fga/2022/345/de), [432](https://www.fedlex.admin.ch/eli/fga/2022/432/de)).

[14](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1543) Eingefügt durch Ziff. I des BG vom 17. Juni 2022 (Arbeitsverhältnis der Leiterin oder des Leiters des Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten), in Kraft seit 1. Sept. 2023 ([AS **2023** 231](https://www.fedlex.admin.ch/eli/oc/2023/231/de); [BBl **2022** 345](https://www.fedlex.admin.ch/eli/fga/2022/345/de), [432](https://www.fedlex.admin.ch/eli/fga/2022/432/de)).

###### [**Art. 44** Amtsdauer, Wiederwahl und Beendigung der Amtsdauer](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_44)

1 Die Amtsdauer der oder des Beauftragten beträgt vier Jahre und kann zwei Mal erneuert werden. Sie beginnt am 1. Januar nach Beginn der Legislaturperiode des Nationalrates.

2 Die oder der Beauftragte kann das Arbeitsverhältnis auf Ende jedes Monats unter Einhaltung einer Kündigungsfrist von sechs Monaten kündigen. Die Gerichtskommission kann der oder dem Beauftragten im Einzelfall eine kürzere Kündigungsfrist zugestehen, wenn keine wesentlichen Interessen entgegenstehen.[15](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1584)

3 Die Vereinigte Bundesversammlung kann die Beauftragte oder den Beauftragten vor Ablauf der Amtsdauer des Amtes entheben, wenn diese oder dieser:

a.

vorsätzlich oder grobfahrlässig Amtspflichten schwer verletzt hat; oder

b.

die Fähigkeit, das Amt auszuüben, auf Dauer verloren hat.

[15](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1584) Fassung Ziff. I des BG vom 17. Juni 2022 (Arbeitsverhältnis der Leiterin oder des Leiters des Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten), in Kraft seit 1. Sept. 2023 ([AS **2023** 231](https://www.fedlex.admin.ch/eli/oc/2023/231/de); [BBl **2022** 345](https://www.fedlex.admin.ch/eli/fga/2022/345/de), [432](https://www.fedlex.admin.ch/eli/fga/2022/432/de)).

###### [**Art. 44**_a_](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_44_a)[16](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1618) [Verwarnung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_44_a)

Die Gerichtskommission kann eine Verwarnung aussprechen, wenn sie feststellt, dass die oder der Beauftragte Amtspflichten verletzt hat.

[16](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1618) Eingefügt durch Ziff. I des BG vom 17. Juni 2022 (Arbeitsverhältnis der Leiterin oder des Leiters des Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten), in Kraft seit 1. Sept. 2023 ([AS **2023** 231](https://www.fedlex.admin.ch/eli/oc/2023/231/de); [BBl **2022** 345](https://www.fedlex.admin.ch/eli/fga/2022/345/de), [432](https://www.fedlex.admin.ch/eli/fga/2022/432/de)).

###### [**Art. 45** Budget](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_45)

Der EDÖB reicht den Entwurf seines Budgets jährlich über die Bundeskanzlei dem Bundesrat ein. Dieser leitet ihn unverändert an die Bundesversammlung weiter.

###### [**Art. 46** Unvereinbarkeit](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_46)

Die oder der Beauftragte darf weder der Bundesversammlung noch dem Bundesrat angehören und in keinem anderen Arbeitsverhältnis mit dem Bund stehen.

###### [**Art. 47** Nebenbeschäftigung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_47)

1 Die oder der Beauftragte darf keine Nebenbeschäftigung ausüben.

2 Die Gerichtskommission kann der oder dem Beauftragten gestatten, eine Nebenbeschäftigung auszuüben, wenn dadurch die Ausübung der Funktion sowie die Unabhängigkeit und das Ansehen des EDÖB nicht beeinträchtigt werden.[17](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1679) Der Entscheid wird veröffentlicht.

[17](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1679) Fassung gemäss Ziff. I des BG vom 17. Juni 2022 (Arbeitsverhältnis der Leiterin oder des Leiters des Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten), in Kraft seit 1. Sept. 2023 ([AS **2023** 231](https://www.fedlex.admin.ch/eli/oc/2023/231/de); [BBl **2022** 345](https://www.fedlex.admin.ch/eli/fga/2022/345/de), [432](https://www.fedlex.admin.ch/eli/fga/2022/432/de)).

###### [**Art. 47**_a_](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_47_a)[18](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1703) [Ausstand](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_47_a)

Ist der Ausstand der oder des Beauftragten streitig, so entscheidet darüber die Präsidentin oder der Präsident der auf dem Gebiet des Datenschutzes zuständigen Abteilung des Bundesverwaltungsgerichts.

[18](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1703) Eingefügt durch Ziff. I des BG vom 17. Juni 2022 (Arbeitsverhältnis der Leiterin oder des Leiters des Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten), in Kraft seit 1. Sept. 2023 ([AS **2023** 231](https://www.fedlex.admin.ch/eli/oc/2023/231/de); [BBl **2022** 345](https://www.fedlex.admin.ch/eli/fga/2022/345/de), [432](https://www.fedlex.admin.ch/eli/fga/2022/432/de)).

###### [**Art. 48** Selbstkontrolle des EDÖB](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_48)

Der EDÖB stellt durch geeignete Kontrollmassnahmen, insbesondere in Bezug auf die Datensicherheit, sicher, dass der rechtskonforme Vollzug der bundesrechtlichen Datenschutzvorschriften innerhalb seiner Behörde gewährleistet ist.

## [2. Abschnitt: Untersuchung von Verstössen gegen Datenschutzvorschriften](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_7/sec_2)

###### [**Art. 49** Untersuchung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_49)

1 Der EDÖB eröffnet von Amtes wegen oder auf Anzeige hin eine Untersuchung gegen ein Bundesorgan oder eine private Person, wenn genügend Anzeichen bestehen, dass eine Datenbearbeitung gegen die Datenschutzvorschriften verstossen könnte.

2 Er kann von der Eröffnung einer Untersuchung absehen, wenn die Verletzung der Datenschutzvorschriften von geringfügiger Bedeutung ist.

3 Das Bundesorgan oder die private Person erteilt dem EDÖB alle Auskünfte und stellt ihm alle Unterlagen zur Verfügung, die für die Untersuchung notwendig sind. Das Auskunftsverweigerungsrecht richtet sich nach den Artikeln 16 und 17 des VwVG[19](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1759), sofern Artikel 50 Absatz 2 des vorliegenden Gesetzes nichts anderes bestimmt.

4 Hat die betroffene Person Anzeige erstattet, so informiert der EDÖB sie über die gestützt darauf unternommenen Schritte und das Ergebnis einer allfälligen Untersuchung.

[19](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1759) [SR **172.021**](https://www.fedlex.admin.ch/eli/cc/1969/737_757_755/de)

###### [**Art. 50** Befugnisse](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_50)

1 Kommt das Bundesorgan oder die private Person den Mitwirkungspflichten nicht nach, so kann der EDÖB im Rahmen der Untersuchung insbesondere Folgendes anordnen:

a.

Zugang zu allen Auskünften, Unterlagen, Verzeichnissen der Bearbeitungstätigkeiten und Personendaten, die für die Untersuchung erforderlich sind;

b.

Zugang zu Räumlichkeiten und Anlagen;

c.

Zeugeneinvernahmen;

d.

Begutachtungen durch Sachverständige.

2 Das Berufsgeheimnis bleibt vorbehalten.

3 Zum Vollzug der Massnahmen nach Absatz 1 kann der EDÖB andere Bundesbehörden sowie die kantonalen oder kommunalen Polizeiorgane beiziehen.

###### [**Art. 51** Verwaltungsmassnahmen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_51)

1 Liegt eine Verletzung von Datenschutzvorschriften vor, so kann der EDÖB verfügen, dass die Bearbeitung ganz oder teilweise angepasst, unterbrochen oder abgebrochen wird und die Personendaten ganz oder teilweise gelöscht oder vernichtet werden.

2 Er kann die Bekanntgabe ins Ausland aufschieben oder untersagen, wenn sie gegen die Voraussetzungen nach Artikel 16 oder 17 oder gegen Bestimmungen betreffend die Bekanntgabe von Personendaten ins Ausland in anderen Bundesgesetzen verstösst.

3 Er kann namentlich anordnen, dass das Bundesorgan oder die private Person:

a.

ihn nach den Artikeln 16 Absatz 2 Buchstaben b und c sowie 17 Absatz 2 informiert;

b.

die Vorkehren nach den Artikeln 7 und 8 trifft;

c.

nach den Artikeln 19 und 21 die betroffenen Personen informiert;

d.

eine Datenschutz-Folgenabschätzung nach Artikel 22 vornimmt;

e.

ihn nach Artikel 23 konsultiert;

f.

ihn oder gegebenenfalls die betroffenen Personen nach Artikel 24 informiert;

g.

der betroffenen Person die Auskünfte nach Artikel 25 erteilt.

4 Er kann auch anordnen, dass der private Verantwortliche mit Sitz oder Wohnsitz im Ausland eine Vertretung nach Artikel 14 bezeichnet.

5 Hat das Bundesorgan oder die private Person während der Untersuchung die erforderlichen Massnahmen getroffen, um die Einhaltung der Datenschutzvorschriften wiederherzustellen, so kann der EDÖB sich darauf beschränken, eine Verwarnung auszusprechen.

###### [**Art. 52** Verfahren](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_52)

1 Das Untersuchungsverfahren sowie Verfügungen nach den Artikeln 50 und 51 richten sich nach dem VwVG[20](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e1863).

2 Partei ist nur das Bundesorgan oder die private Person, gegen das oder die eine Untersuchung eröffnet wurde.

3 Der EDÖB kann Beschwerdeentscheide des Bundesverwaltungsgerichts anfechten.

[20](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e1863) [SR **172.021**](https://www.fedlex.admin.ch/eli/cc/1969/737_757_755/de)

###### [**Art. 53** Koordination](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_53)

1 Bundesverwaltungsbehörden, die nach einem anderen Bundesgesetz private Personen oder Organisationen ausserhalb der Bundesverwaltung beaufsichtigen, laden den EDÖB zur Stellungnahme ein, bevor sie eine Verfügung erlassen, die Fragen des Datenschutzes betrifft.

2 Führt der EDÖB gegen die gleiche Partei eine eigene Untersuchung durch, so koordinieren die beiden Behörden ihre Verfahren.

## [3. Abschnitt: Amtshilfe](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_7/sec_3)

###### [**Art. 54** Amtshilfe zwischen schweizerischen Behörden](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_54)

1 Bundesbehörden und kantonale Behörden geben dem EDÖB die Informationen und Personendaten bekannt, die für die Erfüllung seiner gesetzlichen Aufgaben erforderlich sind.

2 Der EDÖB gibt den folgenden Behörden die Informationen und Personendaten bekannt, die für die Erfüllung ihrer gesetzlichen Aufgaben erforderlich sind:

a.

den Behörden, die in der Schweiz für den Datenschutz zuständig sind;

b.

den zuständigen Strafverfolgungsbehörden, falls es um die Anzeige einer Straftat nach Artikel 65 Absatz 2 geht;

c.

den Bundesbehörden sowie den kantonalen und kommunalen Polizeiorganen für den Vollzug der Massnahmen nach den Artikeln 50 Absatz 3 und 51.

###### [**Art. 55** Amtshilfe gegenüber ausländischen Behörden](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_55)

1 Der EDÖB kann mit ausländischen Behörden, die für den Datenschutz zuständig sind, für die Erfüllung ihrer jeweiligen gesetzlich vorgesehenen Aufgaben im Bereich des Datenschutzes Informationen oder Personendaten austauschen, wenn folgende Voraussetzungen erfüllt sind:

a.

Die Gegenseitigkeit der Amtshilfe ist sichergestellt.

b.

Die Informationen und Personendaten werden nur für das den Datenschutz betreffende Verfahren verwendet, das dem Amtshilfeersuchen zugrunde liegt.

c.

Die empfangende Behörde verpflichtet sich, das Berufsgeheimnis sowie Geschäfts- und Fabrikationsgeheimnisse zu wahren.

d.

Die Informationen und Personendaten werden Dritten nur bekanntgegeben, wenn die Behörde, die sie übermittelt hat, dies vorgängig genehmigt.

e.

Die empfangende Behörde verpflichtet sich, die Auflagen und Einschränkungen der Behörde einzuhalten, die ihr die Informationen und Personendaten übermittelt hat.

2 Um sein Amtshilfegesuch zu begründen oder um dem Ersuchen einer Behörde Folge zu leisten, kann der EDÖB insbesondere folgende Angaben machen:

a.

Identität des Verantwortlichen, des Auftragsbearbeiters oder anderer beteiligter Dritter;

b.

Kategorien der betroffenen Personen;

c.

Identität der betroffenen Personen, falls:

1.

die betroffenen Personen eingewilligt haben, oder

2.

die Mitteilung der Identität der betroffenen Personen unentbehrlich ist zur Erfüllung der gesetzlichen Aufgaben durch den EDÖB oder die ausländische Behörde;

d.

bearbeitete Personendaten oder Kategorien bearbeiteter Personendaten;

e.

Bearbeitungszweck;

f.

Empfängerinnen und Empfänger oder die Kategorien der Empfängerinnen und Empfänger;

g.

technische und organisatorische Massnahmen.

3 Bevor der EDÖB einer ausländischen Behörde Informationen bekanntgibt, die ein Berufsgeheimnis, Geschäfts- oder Fabrikationsgeheimnisse enthalten können, informiert er die betroffenen natürlichen oder juristischen Personen, die Trägerinnen dieser Geheimnisse sind, und lädt sie zur Stellungnahme ein, es sei denn, dies ist nicht möglich oder erfordert einen unverhältnismässigen Aufwand.

## [4. Abschnitt: Andere Aufgaben des EDÖB](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_7/sec_4)

###### [**Art. 56** Register](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_56)

Der EDÖB führt ein Register der Bearbeitungstätigkeiten der Bundesorgane. Das Register wird veröffentlicht.

###### [**Art. 57** Information](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_57)

1 Der EDÖB erstattet der Bundesversammlung jährlich Bericht über seine Tätigkeit. Er übermittelt ihn gleichzeitig dem Bundesrat. Der Bericht wird veröffentlicht.

2 In Fällen von allgemeinem Interesse informiert der EDÖB die Öffentlichkeit über seine Feststellungen und Verfügungen.

###### [**Art. 58** Weitere Aufgaben](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_58)

1 Der EDÖB nimmt darüber hinaus insbesondere folgende Aufgaben wahr:

a.

Er informiert, schult und berät die Bundesorgane sowie private Personen in Fragen des Datenschutzes.

b.

Er unterstützt die kantonalen Organe und arbeitet mit schweizerischen und ausländischen Behörden, die für den Datenschutz zuständig sind, zusammen.

c.

Er sensibilisiert die Bevölkerung, insbesondere schutzbedürftige Personen, in Bezug auf den Datenschutz.

d.

Er erteilt betroffenen Personen auf Anfrage Auskunft darüber, wie sie ihre Rechte ausüben können.

e.

Er nimmt Stellung zu Erlassentwürfen und Massnahmen des Bundes, die eine Datenbearbeitung zur Folge haben.

f.

Er nimmt die ihm durch das Öffentlichkeitsgesetz vom 17. Dezember 2004[21](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2057) oder andere Bundesgesetze übertragenen Aufgaben wahr.

g.

Er erarbeitet Arbeitsinstrumente als Empfehlungen der guten Praxis zuhanden von Verantwortlichen, Auftragsbearbeitern und betroffenen Personen; hierfür berücksichtigt er die Besonderheiten des jeweiligen Bereichs sowie den Schutz von schutzbedürftigen Personen.

2 Er kann auch Bundesorgane beraten, die gemäss den Artikeln 2 und 4 nicht seiner Aufsicht unterstehen. Die Bundesorgane können ihm Akteneinsicht gewähren.

3 Der EDÖB ist befugt, gegenüber den ausländischen Behörden, die für den Datenschutz zuständig sind, zu erklären, dass im Bereich des Datenschutzes in der Schweiz die direkte Zustellung zulässig ist, sofern der Schweiz Gegenrecht gewährt wird.

[21](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2057) [SR **152.3**](https://www.fedlex.admin.ch/eli/cc/2006/355/de)

## [5. Abschnitt: Gebühren](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_7/sec_5)

###### [**Art. 59**](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_59)

1 Der EDÖB erhebt von privaten Personen Gebühren für:

a.

die Stellungnahme zu einem Verhaltenskodex nach Artikel 11 Absatz 2;

b.

die Genehmigung von Standarddatenschutzklauseln und verbindlichen unternehmensinternen Datenschutzvorschriften nach Artikel 16 Absatz 2 Buchstaben d und e;

c.

die Konsultation aufgrund einer Datenschutz-Folgenabschätzung nach Artikel 23 Absatz 2;

d.

vorsorgliche Massnahmen und Massnahmen nach Artikel 51;

e.

Beratungen in Fragen des Datenschutzes nach Artikel 58 Absatz 1 Buchstabe a.

2 Der Bundesrat legt die Höhe der Gebühren fest.

3 Er kann festlegen, in welchen Fällen es möglich ist, auf die Erhebung einer Gebühr zu verzichten oder sie zu reduzieren.

# [8. Kapitel: Strafbestimmungen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_8)

###### [**Art. 60** Verletzung von Informations-, Auskunfts- und Mitwirkungspflichten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_60)

1 Mit Busse bis zu 250 000 Franken werden private Personen auf Antrag bestraft:

a.

die ihre Pflichten nach den Artikeln 19, 21 und 25–27 verletzen, indem sie vorsätzlich eine falsche oder unvollständige Auskunft erteilen;

b.

die es vorsätzlich unterlassen:

1.

die betroffene Person nach den Artikeln 19 Absatz 1 und 21 Absatz 1 zu informieren, oder

2.

ihr die Angaben nach Artikel 19 Absatz 2 zu liefern.

2 Mit Busse bis zu 250 000 Franken werden private Personen bestraft, die unter Verstoss gegen Artikel 49 Absatz 3 dem EDÖB im Rahmen einer Untersuchung vorsätzlich falsche Auskünfte erteilen oder vorsätzlich die Mitwirkung verweigern.

###### [**Art. 61** Verletzung von Sorgfaltspflichten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_61)

Mit Busse bis zu 250 000 Franken werden private Personen auf Antrag bestraft, die vorsätzlich:

a.

unter Verstoss gegen Artikel 16 Absätze 1 und 2 und ohne dass die Voraussetzungen nach Artikel 17 erfüllt sind, Personendaten ins Ausland bekanntgeben;

b.

die Datenbearbeitung einem Auftragsbearbeiter übergeben, ohne dass die Voraussetzungen nach Artikel 9 Absätze 1 und 2 erfüllt sind;

c.

die Mindestanforderungen an die Datensicherheit, die der Bundesrat nach Artikel 8 Absatz 3 erlassen hat, nicht einhalten.

###### [**Art. 62** Verletzung der beruflichen Schweigepflicht](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_62)

1 Wer geheime Personendaten vorsätzlich offenbart, von denen sie oder er bei der Ausübung ihres oder seines Berufes, der die Kenntnis solcher Daten erfordert, Kenntnis erlangt hat, wird auf Antrag mit Busse bis zu 250 000 Franken bestraft.

2 Gleich wird bestraft, wer vorsätzlich geheime Personendaten offenbart, von denen sie oder er bei der Tätigkeit für eine geheimhaltungspflichtige Person oder während der Ausbildung bei dieser Kenntnis erlangt hat.

3 Das Offenbaren geheimer Personendaten ist auch nach Beendigung der Berufsausübung oder der Ausbildung strafbar.

###### [**Art. 63** Missachten von Verfügungen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_63)

Mit Busse bis zu 250 000 Franken werden private Personen bestraft, die einer Verfügung des EDÖB oder einem Entscheid der Rechtsmittelinstanzen, die oder der unter Hinweis auf die Strafdrohung dieses Artikels ergangen ist, vorsätzlich nicht Folge leisten.

###### [**Art. 64** Widerhandlungen in Geschäftsbetrieben](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_64)

1 Für Widerhandlungen in Geschäftsbetrieben sind die Artikel 6 und 7 des Bundesgesetzes vom 22. März 1974[22](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2220) über das Verwaltungsstrafrecht (VStrR) anwendbar.

2 Fällt eine Busse von höchstens 50 000 Franken in Betracht und würde die Ermittlung der nach Artikel 6 VStrR strafbaren Personen Untersuchungsmassnahmen bedingen, die im Hinblick auf die verwirkte Strafe unverhältnismässig wären, so kann die Behörde von einer Verfolgung dieser Personen absehen und an ihrer Stelle den Geschäftsbetrieb (Art. 7 VStrR) zur Bezahlung der Busse verurteilen.

[22](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2220) [SR **313.0**](https://www.fedlex.admin.ch/eli/cc/1974/1857_1857_1857/de)

###### [**Art. 65** Zuständigkeit](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_65)

1 Die Verfolgung und die Beurteilung strafbarer Handlungen obliegen den Kantonen.

2 Der EDÖB kann bei der zuständigen Strafverfolgungsbehörde Anzeige erstatten und im Verfahren die Rechte einer Privatklägerschaft wahrnehmen.

###### [**Art. 66** Verfolgungsverjährung](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_66)

Die Strafverfolgung verjährt nach fünf Jahren.

# [9. Kapitel: Abschluss von Staatsverträgen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_9)

###### [**Art. 67**](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_67)

Der Bundesrat kann Staatsverträge abschliessen betreffend:

a.

die internationale Zusammenarbeit zwischen Datenschutzbehörden;

b.

die gegenseitige Anerkennung eines angemessenen Schutzes für die Bekanntgabe von Personendaten ins Ausland.

# [10. Kapitel: Schlussbestimmungen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#chap_10)

###### [**Art. 68** Aufhebung und Änderung anderer Erlasse](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_68)

Die Aufhebung und die Änderung anderer Erlasse werden im Anhang 1 geregelt.

###### [**Art. 69** Übergangsbestimmungen betreffend laufende Bearbeitungen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_69)

Die Artikel 7, 22 und 23 sind nicht anwendbar auf Datenbearbeitungen, die vor Inkrafttreten dieses Gesetzes begonnen wurden, wenn der Bearbeitungszweck unverändert bleibt und keine neuen Daten beschafft werden.

###### [**Art. 70** Übergangsbestimmung betreffend laufende Verfahren](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_70)

Dieses Gesetz gilt nicht für Untersuchungen des EDÖB, die im Zeitpunkt seines Inkrafttretens hängig sind; es ist ebenfalls nicht anwendbar auf hängige Beschwerden gegen erstinstanzliche Entscheide, die vor seinem Inkrafttreten ergangen sind. Diese Fälle unterstehen dem bisherigen Recht.

###### [**Art. 71** Übergangsbestimmung betreffend Daten juristischer Personen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_71)

Für Bundesorgane finden Vorschriften in anderen Bundeserlassen, die sich auf Personendaten beziehen, während fünf Jahren nach Inkrafttreten dieses Gesetzes weiter Anwendung auf Daten juristischer Personen. Insbesondere können Bundesorgane während fünf Jahren nach Inkrafttreten dieses Gesetzes Daten juristischer Personen nach Artikel 57_s_ Absätze 1 und 2 des Regierungs- und Verwaltungsorganisationsgesetzes vom 21. März 1997[23](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2317) weiterhin bekanntgeben, wenn sie gestützt auf eine Rechtsgrundlage zur Bekanntgabe von Personendaten ermächtigt sind.

[23](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2317) [SR **172.010**](https://www.fedlex.admin.ch/eli/cc/1997/2022_2022_2022/de)

###### [**Art. 72** Übergangsbestimmung betreffend die Wahl und die Beendigung der Amtsdauer der oder des Beauftragten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_72)

1 Die Wahl der oder des Beauftragten sowie die Beendigung ihrer oder seiner Amtsdauer unterstehen bis zum Ende der Legislaturperiode, in der dieses Gesetz in Kraft tritt, dem bisherigen Recht.

2 Wird bei der erstmaligen Wahl der oder des Beauftragten durch die Vereinigte Bundesversammlung die bisherige Amtsinhaberin oder der bisherige Amtsinhaber gewählt, beginnt die neue Amtsdauer der oder des Beauftragten am Tag nach der Wahl.[24](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2338)

[24](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2338) Eingefügt durch Ziff. I des BG vom 17. Juni 2022 (Arbeitsverhältnis der Leiterin oder des Leiters des Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten), in Kraft seit 1. Sept. 2023 ([AS **2023** 231](https://www.fedlex.admin.ch/eli/oc/2023/231/de); [BBl **2022** 345](https://www.fedlex.admin.ch/eli/fga/2022/345/de), [432](https://www.fedlex.admin.ch/eli/fga/2022/432/de)).

###### [**Art. 72**_a_](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_72_a)[25](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2360) [Übergangsbestimmung betreffend das Arbeitsverhältnis  
der oder des Beauftragten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_72_a)

Für das Arbeitsverhältnis der oder des Beauftragten, das nach bisherigem Recht begründet worden ist, gilt das bisherige Recht.

[25](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2360) Eingefügt durch Ziff. I des BG vom 17. Juni 2022 (Arbeitsverhältnis der Leiterin oder des Leiters des Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten), in Kraft seit 1. Sept. 2023 ([AS **2023** 231](https://www.fedlex.admin.ch/eli/oc/2023/231/de); [BBl **2022** 345](https://www.fedlex.admin.ch/eli/fga/2022/345/de), [432](https://www.fedlex.admin.ch/eli/fga/2022/432/de)).

###### [**Art. 73** Koordination](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_73)

Die Koordination mit anderen Erlassen wird im Anhang 2 geregelt.

###### [**Art. 74** Referendum und Inkrafttreten](https://www.fedlex.admin.ch/eli/cc/2022/491/de#art_74)

1 Dieses Gesetz untersteht dem fakultativen Referendum.

2 Der Bundesrat bestimmt das Inkrafttreten.

Inkrafttreten: 1. September 2023[26](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2407)

[26](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2407) BRB vom 31. Aug. 2022

# [Anhang 1](https://www.fedlex.admin.ch/eli/cc/2022/491/de#annex_1)

(Art. 68)

## [Aufhebung und Änderung anderer Erlasse](https://www.fedlex.admin.ch/eli/cc/2022/491/de#annex_1/lvl_u1)

I

Die folgenden Erlasse werden aufgehoben:

1.

Bundesgesetz vom 19. Juni 1992[27](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2429) über den Datenschutz;

2.

Schengen-Datenschutzgesetz vom 28. September 2018[28](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2511).

II

Die nachstehenden Erlasse werden wie folgt geändert:

…[29](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2530)

[27](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2429) [[AS **1993** 1945](https://www.fedlex.admin.ch/eli/oc/1993/1945_1945_1945/de); [**1997** 2372](https://www.fedlex.admin.ch/eli/oc/1997/2372_2372_2372/de) Ziff. II; **1998** 1546 Art. 31, [**1999** 2243](https://www.fedlex.admin.ch/eli/oc/1999/354/de) Art. 25; [**2006** 2197](https://www.fedlex.admin.ch/eli/oc/2006/352/de) Anhang Ziff. 26, [2319](https://www.fedlex.admin.ch/eli/oc/2006/355/de) Anhang Ziff. 4; [**2007** 4983](https://www.fedlex.admin.ch/eli/oc/2007/699/de); [**2010** 1739](https://www.fedlex.admin.ch/eli/oc/2010/262/de) Anhang 1 Ziff. II 14, [3387](https://www.fedlex.admin.ch/eli/oc/2010/464/de) Ziff. 3; [**2013** 3215](https://www.fedlex.admin.ch/eli/oc/2013/617/de) Anhang Ziff. 1; [**2019** 625](https://www.fedlex.admin.ch/eli/oc/2019/111/de) Ziff. II 1]

[28](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2511) [[AS **2019** 639](https://www.fedlex.admin.ch/eli/oc/2019/112/de)]

[29](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2530) Die Änderungen können unter [AS **2022** 491](https://www.fedlex.admin.ch/eli/oc/2022/491/de) konsultiert werden.

# [Anhang 2](https://www.fedlex.admin.ch/eli/cc/2022/491/de#annex_2)

(Art. 73)

## [Koordination mit anderen Erlassen](https://www.fedlex.admin.ch/eli/cc/2022/491/de#annex_2/lvl_u1)[30](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fn-d7e2548)

[30](https://www.fedlex.admin.ch/eli/cc/2022/491/de#fnbck-d7e2548) Die Koordinationsbestimmungen können unter [AS **2022** 491](https://www.fedlex.admin.ch/eli/oc/2022/491/de) konsultiert werden.